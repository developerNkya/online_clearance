package com.example.scannerapp;

public class scan_Page {
}
